import numpy as np
import time
import re
import operator
import pandas as pd
from UnbiasedGBM import UnbiasedBoost


def main(data, num_gene, time_points, k, alpha, feature_num, iter_num, min_leaf_num):
    time_start = time.time()

    data1 = np.hstack((data[0,:,:], data[1,:,:], data[2,:,:]))
    data2 = np.zeros((3, num_gene, int((np.shape(data1)[1])/3)))

    for i in range(3):
        data2[i, :, :] = data1[:, i*time_points : (i+1)*time_points]

    # Compute the accumulation of previous time points for time-series data.
    data_tm  = time_series(data2, k, alpha)

    # Compute the weights of gene regulatory network using UGBMNet.
    mgr_ugbmnet = ugbmnet_weight(data_tm, feature_num, iter_num, min_leaf_num)
    mgr_ugbmnet = np.transpose(mgr_ugbmnet)
    print('shape of weights after UGBMNet is: ', np.shape(mgr_ugbmnet))
    
        
    # Use a statistical technology to refine the inferred GRN.
    statis = statistical_method(mgr_ugbmnet)
    mgr = mgr_ugbmnet * statis

    # Compute the running time
    time_end = time.time()
    print('totally cost (seconds)', time_end - time_start)

    return mgr


def time_series(data, k, alpha):
    """
    Compute the accumulation of previous time points for time series-data.

    Args:

        data: Time-series experimental data (3D), shape (d*m*n). d: number of 2D matrix, m: number of timeseries-data, n: number of time points
        k: previous k time points.
        alpha: decay factor.

    Returns:

        kdata: matrix after computing previous time points (2D), whose shape is ( (d*(n-k)) * m )

    """
    data_3d = np.shape(data)[0]
    data_raw = np.shape(data)[1]
    data_column = np.shape(data)[2] - k
    m_accu  = np.zeros((data_3d, data_raw, data_column))

    for p in range(data_3d):
        for q in range(data_raw):
            for r in range(data_column):
                element = 0
                i = 0
                while i <= k:
                    element += pow(alpha, k-i) * data[p, q, r+i]
                    i += 1
                m_accu[p,q,r] = element

    kdata = np.transpose(np.hstack((m_accu[0,:,:], m_accu[1,:,:], m_accu[2,:,:])))
    print('shape of kdata is : ', np.shape(kdata))

    return kdata


def ugbmnet_weight(data, feature_num, iter_num, min_leaf_num):
    """
    Compute the weights of gene regulatory network using UnbiasedGBM.

    Args:

        data: Experimental data.
        feature_num: Number of regulator genes.
        iter_num: Number of iterations.
        min_leaf_num: Minimum number of samples required to be at a leaf node.

    Returns:

        mgr_ugbmnet: The matrix recording the weights of regulatory network after using UnbiasedGBM.

    """
        
    print('shape of data for UnbiasedGBM is : ', np.shape(data))
    mgr_ugbmnet = np.zeros((data.shape[1], feature_num))

    for i in range(0, data.shape[1]):
        print("----------------------------------------------------------------", i, "----------------------------------------------------------------")

        y = data[:, i]
        if i == 0:
            x = data[:, 1:feature_num]
        elif i < feature_num:
            x = np.hstack((data[:, 0:i], data[:, i+1:feature_num]))
        else:
            x = data[:, 0:feature_num]
        print('shape of x is : ', np.shape(x))

        X_train = pd.DataFrame(x, columns=[str(j) for j in range(x.shape[1])])
        y_train = pd.Series(y)

        model = UnbiasedBoost(
            losstool = 'MSE',   # Loss function type: 'MSE' for regression, 'logloss' for classification.
            n_est = iter_num,   # Number of boosting iterations.
            min_leaf = min_leaf_num,    # Minimum number of samples required in a leaf node (controls tree depth).
            thresh = 0.001,     # Split threshold: minimum gain required to perform a split (regularization).
            n_data_split = 4,   # Number of data partitions for parallel computation (optional).
            lr = 0.0010,        # Learning rate (shrinkage factor) for each tree's contribution.
            seed = 1,           # Random seed for reproducibility.
            n_leaf = 2          # Number of leaf nodes in each tree (tree complexity).
        )
        model.fit(X_train, y_train)
        
        # Compute and sort feature importance
        importance = model.calc_self_imp()
        importance = sorted(importance.items(), key=operator.itemgetter(1), reverse=True)
        print('shape of the importance matrix is : ', np.shape(importance))

        # Convert the importance list to matrix weights
        for j in range(0, len(importance)):
            num = re.findall(r'\d+', importance[j][0])
            num = np.array(num)
            num = np.char.strip(num, '()')
            num = int(num)
            if i >= feature_num - 1:
                fea_num = num
            else:
                if num < i:
                    fea_num = num
                else:
                    fea_num = num + 1
            mgr_ugbmnet[i][fea_num] = importance[j][1]
        
    return mgr_ugbmnet


def statistical_method(x):
    # Use a statistical technology to further refine the inferred GRN.
    p = np.shape(x)[0]
    q = np.shape(x)[1]
    mv = np.var(x, axis=1, ddof=1)
    w = np.zeros((p, q))
    for i in range(p):
        w[i, :] = mv[i]
    return w
