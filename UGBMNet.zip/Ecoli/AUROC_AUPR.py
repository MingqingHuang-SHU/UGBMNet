from AUROC_AUPR_Ecoli import *
import pandas as pd

def main():
    auroc = []
    aupr = []

    # cold_data example
    filename_cold = "test_mgr_cold"
    auroc_cold, aupr_cold = AUROC_AUPR(filename_cold)
    auroc.append(auroc_cold)
    aupr.append(aupr_cold)

    # heat_data example
    filename_heat = "test_mgr_heat"
    auroc_heat, aupr_heat = AUROC_AUPR(filename_heat)
    auroc.append(auroc_heat)
    aupr.append(aupr_heat)

    # oxi_data example
    filename_oxi = "test_mgr_oxi"
    auroc_oxi, aupr_oxi = AUROC_AUPR(filename_oxi)
    auroc.append(auroc_oxi)
    aupr.append(aupr_oxi)

    print(f"auroc values: {auroc}")
    print(f"aupr values: {aupr}")

    with open("AUROC_AUPR/AUROC_AUPR.txt", 'w', encoding='utf-8') as result_file:
        result_file.write(f"auroc values: {auroc}\n")  # Write auroc values
        result_file.write(f"aupr values: {aupr}")  # Write aupr values

    return auroc, aupr

def AUROC_AUPR(filename):
    # File paths
    gold_file = "AUROC_AUPR/Gnumber_gold_standard.csv"
    test_file = "AUROC_AUPR/{}.csv".format(filename)
        
    print("\n\nReading gold file Gnumber_gold_standard...")
    gold_edges, num_row = read_gold_edges(gold_file)
    print(f"Read {num_row} true edges from gold file")
        
    print("\nReading test file {}...".format(filename))
    predictions = read_predictions(test_file)
    print(f"Read {len(predictions)} predicted edges from test file")
        
    print("\nCalculating evaluation metrics...")
    auroc_current, aupr_current, precision, recall, fpr, tpr, y_true, y_score = calculate_metrics(gold_edges, predictions)
        
    print(f"\n========== Results ==========")
    print(f"AUROC_{filename}: {auroc_current:.6f}")
    print(f"AUPR_{filename}: {aupr_current:.6f}")
    
    # Display some statistical information
    print(f"\n========== Statistics ==========")
    print(f"Total edges considered: {len(y_true)}")
    print(f"True positives: {np.sum(y_true)}")
    print(f"True negatives: {len(y_true) - np.sum(y_true)}")
    print(f"Prediction score range: [{np.min(y_score):.6f}, {np.max(y_score):.6f}]")
    print(f"Mean prediction score: {np.mean(y_score):.6f}")
    
    # Display some prediction examples
    print(f"\n========== Prediction Examples ==========")
    print("Top 5 predicted edges (sorted by score descending):")
    sorted_predictions = sorted(predictions.items(), key=lambda x: x[1], reverse=True)
    for i, ((src, dst), score) in enumerate(sorted_predictions[:5]):
        is_correct = (src, dst) in gold_edges
        status = "✓" if is_correct else "✗"
        print(f"  {status} {src}->{dst}: {score:.6f} {'(correct)' if is_correct else '(incorrect)'}")
    
    # Display prediction score distribution for positives and negatives
    print(f"\nMean prediction score for positives: {np.mean(y_score[y_true == 1]):.6f}")
    print(f"Mean prediction score for negatives: {np.mean(y_score[y_true == 0]):.6f}")
        
    print(f"auroc_{filename} value: {auroc_current}")
    print(f"aupr_{filename} value: {aupr_current}")

    return auroc_current, aupr_current

if __name__ == "__main__":
    auroc, aupr = main()
    