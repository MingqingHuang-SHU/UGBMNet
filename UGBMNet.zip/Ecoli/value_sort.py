import pandas as pd

def value_sort(filename):
    # Read CSV file
    df = pd.read_csv('results/{}.csv'.format(filename), header=None)

    # Extract data part (excluding the index in the first row)
    data = df.iloc[1:, :].values

    # List to store results
    result = []

    # Iterate over all cells
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            # Skip cells where row number equals column number (diagonal values)
            if i == j:
                continue
            value = data[i, j]
            Gi, Gj = i+1, j+1
            result.append(("G"+str(Gi), "G"+str(Gj), value))

    # Sort by regulatory value in descending order
    result_sorted = sorted(result, key=lambda x: x[2], reverse=True)

    # Convert to DataFrame
    output_df = pd.DataFrame(result_sorted, columns=['Row', 'Column', 'Value'])

    # Save to CSV file
    output_df.to_csv('AUROC_AUPR/test_{}.csv'.format(filename), header=False, index=False)

    print(f"\nSorting completed for table {filename}, Found {len(result_sorted)} regulatory values.")
    print(f"Top 3 maximum values:")
    for i in range(3):
        print(f"  Rank {i+1}: {result_sorted[i][2]} (Position: Row {result_sorted[i][0]}, Column {result_sorted[i][1]})")


# cold_data example
filename_cold = "mgr_cold"
value_sort(filename_cold)

# heat_data example
filename_heat = "mgr_heat"
value_sort(filename_heat)

# oxi_data example
filename_oxi = "mgr_oxi"
value_sort(filename_oxi)
