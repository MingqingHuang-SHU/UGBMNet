import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score, precision_recall_curve, roc_curve

def read_gold_edges(gold_file_path):
    """
    Read true edges from gold file until encountering a row with value 0
    Returns: set of true edges and count of true edges
    """
    gold_edges = set()
    num_row = 0
    
    with open(gold_file_path, 'r') as f:
        for line in f:
            parts = line.strip().split(',')
            if len(parts) >= 3:
                src = parts[0].strip()
                dst = parts[1].strip()
                label = int(float(parts[2].strip()))  # Handle possible float values
                
                if label == 1:
                    gold_edges.add((src, dst))
                    num_row += 1
                else:
                    # Stop reading when encountering 0
                    break

    return gold_edges, num_row

def read_predictions(test_file_path):
    """
    Read predicted edges and their prediction probabilities from test file
    Returns: dictionary of predicted edges (edge->prediction probability) and set of all nodes
    """
    predictions = {}
    
    with open(test_file_path, 'r') as f:
        for line in f:
            parts = line.strip().split(',')
            if len(parts) >= 3:
                src = parts[0].strip()
                dst = parts[1].strip()
                score = float(parts[2].strip())
                
                predictions[(src, dst)] = score
    
    return predictions

def calculate_metrics(gold_edges, predictions):
    """
    Calculate AUROC and AUPR
    """
    # Get all possible edges (appearing in gold or predictions)
    all_edges = set(gold_edges)
    all_edges.update(predictions.keys())
    
    # Prepare true labels and prediction scores
    y_true = []
    y_score = []
    
    for edge in all_edges:
        # True label: 1 indicates edge exists, 0 indicates edge doesn't exist
        true_label = 1 if edge in gold_edges else 0
        y_true.append(true_label)
        
        # Prediction score: use prediction score if edge is in predictions, otherwise 0
        pred_score = predictions.get(edge, 0.0)
        y_score.append(pred_score)
    
    # Convert to numpy arrays
    y_true = np.array(y_true)
    y_score = np.array(y_score)
    
    # Calculate AUROC
    auroc = roc_auc_score(y_true, y_score)
    
    # Calculate AUPR
    aupr = average_precision_score(y_true, y_score)
    
    # Calculate detailed data for PR curve and ROC curve (if needed)
    precision, recall, _ = precision_recall_curve(y_true, y_score)
    fpr, tpr, _ = roc_curve(y_true, y_score)
    
    return auroc, aupr, precision, recall, fpr, tpr, y_true, y_score
