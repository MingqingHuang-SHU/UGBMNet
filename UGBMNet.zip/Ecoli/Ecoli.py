from UGBMNet_Ecoli import *
import pandas as pd


# cold_data example
cold_data = np.transpose(np.matrix(pd.read_csv('data/ecoli_cold_data.txt', sep='\t')))
cold_tm = np.zeros((3,1484,8))
for i in range(3):
    cold_tm[i, :, :] = cold_data[:, i*8 : (i+1)*8]

mgr_cold = main(cold_tm, 1484, 8, 2, 0.530, 163, 4000, 3)
df = pd.DataFrame(mgr_cold)
df.to_csv('results/mgr_cold.csv',index=False)


# heat_data example
heat_data = np.transpose(np.matrix(pd.read_csv('data/ecoli_heat_data.txt', sep='\t')))
heat_tm = np.zeros((3, 1484, 8))
for i in range(3):
    heat_tm[i, :, :] = heat_data[:, i*8 : (i+1)*8]

mgr_heat = main(heat_tm, 1484, 8, 2, 0.350, 163, 2000, 2)
df = pd.DataFrame(mgr_heat)
df.to_csv('results/mgr_heat.csv',index=False)


# oxi_data example
oxi_data = np.transpose(np.matrix(pd.read_csv('data/ecoli_oxi_data.txt', sep='\t')))
oxi_tm = np.zeros((3, 1484, 11))
for i in range(3):
    oxi_tm[i, :, :] = oxi_data[:, i*11 : (i+1)*11]

mgr_oxi = main(oxi_tm, 1484, 11, 2, 0.510, 163, 1000, 4)
df = pd.DataFrame(mgr_oxi)
df.to_csv('results/mgr_oxi.csv',index=False)
