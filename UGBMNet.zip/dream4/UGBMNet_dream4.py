import numpy as np
import math
import time
import operator
import re
import pandas as pd
from UnbiasedGBM import UnbiasedBoost


def main(data_tm, sample_num, k, alpha, iter_num, data_ko):
    """
    Inferring gene regulatory networks (GRNs) from gene expression data using an integrative UnbiasedBoost-based method.

    Args:

        data_tm: Time-series experimental data.
        sample_num: Number of time-series experimental's samples.
        k: Previous k time points.
        alpha: Decay factor.
        iter_num: Number of iterations in UnbiasedBoost model.
        data_ko: Knockout experimental data.

    Returns:

        mgr: A matrix recording the weights of regulatory network.

    """
    time_start = time.time()

    # Compute the accumulation of previous time points for time-series data.
    x, y = time_accumu(data_tm, sample_num, k, alpha)

    # Compute the weights of gene regulatory network using UnbiasedBoost.
    feature_num = np.shape(data_tm)[1]
    mgrc = ugbmnet_weight(x, y, feature_num, iter_num)
    mgrc = np.transpose(mgrc)

    # Normalize inferred GRN matrix by column with L2-norm method.
    mgr = normalized_l2norm(mgrc)

    # Integrate knockout data
    mko = normalized_zscore(data_ko, 0)
    mgr = mgr * mko

    # Use a statistical technology to refine the inferred GRN.
    statis = statistical_method(mgr)
    mgr = mgr * statis

    # Compute the running time
    time_end = time.time()
    print('time consumption (seconds): ', time_end - time_start)

    return mgr


def time_accumu(data, sample_num, k, alpha):
    """
    Compute the accumulation of previous time points for time-series data.

    Args:
        data: Time-series experimental data.
        sample_num: Number of samples.
        k: previous k time points.
        alpha: decay factor.

    Returns:
        matrixx: Training data after accumulating several time points.
        matrixy: Labels of the training data after accumulating several time points.

    """
    m = int(np.shape(data)[0] / sample_num)
    k = k + 1
    data_initial = data
    matrixx = np.ones(((m - k + 1) * sample_num, np.shape(data_initial)[1]))
    matrixy = np.ones(((m - k + 1) * sample_num, np.shape(data_initial)[1]))

    for t in range(np.shape(data_initial)[1]):
        data = data_initial[:, t]
        wwx = []
        wwy = []
        matx = np.ones(((m - k + 1) * sample_num, 1))
        maty = np.ones(((m - k + 1) * sample_num, 1))
        for j in range(sample_num):
            x = []
            w = []
            XX = 0
            for i in range(k):
                x.append(range(k - i - 1 + m * j, m - i + m * j))
                w.append(pow(alpha, i))
            w = w[0:k - 1]
            for i in range(1, k):
                X = w[i - 1] * data[x[i]]
                XX = XX + X
            YY = data[x[0]]
            wwx.append(XX)
            matx[(m - k + 1) * j:(m - k + 1) * j + (m - k + 1)] = wwx[j].reshape((m - k + 1), 1)
            wwy.append(YY)
            maty[(m - k + 1) * j:(m - k + 1) * j + (m - k + 1)] = wwy[j].reshape((m - k + 1), 1)
        matrixx[:, t] = matx.reshape((m - k + 1) * sample_num, )
        matrixy[:, t] = maty.reshape((m - k + 1) * sample_num, )

    return matrixx, matrixy


def ugbmnet_weight(x, y, subprob_num, iter_num):
    data = x
    d_size = data.shape
    mgrc = np.zeros((d_size[1], subprob_num))

    for i in range(0, d_size[1]):
        print("----------------------------------------------------------------", i, "----------------------------------------------------------------")
        y_current = y[:, i].reshape(d_size[0], 1)
        # Build x_data (same as original logic)
        if i == 0:
            x_data = data[:, 1:subprob_num]
        elif i < subprob_num:
            x_data = np.hstack((data[:, 0:i], data[:, i + 1:subprob_num]))
        else:
            x_data = data[:, 0:subprob_num]

        # ===== Critical fix: convert column names to strings =====
        X_train = pd.DataFrame(x_data, columns=[str(j) for j in range(x_data.shape[1])])
        y_train = pd.Series(y_current.ravel())

        # Build and train model
        model = UnbiasedBoost(
            losstool = 'MSE',   # Loss function type: 'MSE' for regression, 'logloss' for classification
            n_est = iter_num,   # Number of boosting iterations (trees)
            min_leaf = 1,       # Minimum number of samples required in a leaf node (controls tree depth)
            thresh = 0.0001,    # Split threshold: minimum gain required to perform a split (regularization)
            n_data_split = 4,   # Number of data partitions for parallel computation (optional)
            lr = 0.0024,        # Learning rate (shrinkage factor) for each tree's contribution
            seed = 1,           # Random seed for reproducibility
            n_leaf = 6          # Number of leaf nodes in each tree (tree complexity)
        )
        model.fit(X_train, y_train)

        # Compute and sort feature importance
        importance = model.calc_self_imp()
        importance = sorted(importance.items(), key=operator.itemgetter(1), reverse=True)

        # Convert the importance list to matrix weights
        for j in range(0, len(importance)):
            num = re.findall(r'\d+', importance[j][0])
            num = np.array(num)
            num = np.char.strip(num, '()')
            num = int(num)
            
            if i >= subprob_num:
                fea_num = num
            else:
                if num < i:
                    fea_num = num
                else:
                    fea_num = num + 1
            mgrc[i][fea_num] = importance[j][1]

    return mgrc


def normalized_l2norm(x):
    # Normalize matrix by column with L2-norm method.
    p = np.shape(x)[0]
    q = np.shape(x)[1]
    y = np.power(x, 2)
    w = np.zeros((p, q))
    for j in range(q):
        y_sum = sum(y[:, j])
        for i in range(p):
            w[i, j] =  x[i, j] / math.sqrt(y_sum)
    return w


def normalized_zscore(x, ddof=0):
    # Normalize matrix by column with Z-score method.
    m = np.shape(x)[0]
    n = np.shape(x)[1]
    x_std = np.std(x, axis=0, ddof=ddof)
    beta = np.zeros((n))
    w = np.zeros((m, n))
    for j in range(n):
        beta[j] = sum(x[:, j]) / m
        for i in range(m):   
            w[i, j] = abs((x[i, j] - beta[j]) / x_std[j])
    return w


def statistical_method(x):
    # Use a statistical technology to further refine the inferred GRN.
    p = np.shape(x)[0]
    q = np.shape(x)[1]
    mv = np.var(x, axis=1, ddof=1)
    w = np.zeros((p, q))
    for i in range(p):
        w[i, :] = mv[i]
    return w
