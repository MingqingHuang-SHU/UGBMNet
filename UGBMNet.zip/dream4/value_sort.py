import pandas as pd

for num_table in range(1, 6):
    # Read CSV file
    df = pd.read_csv('results/dream4_d{}.csv'.format(num_table), header=None)

    # Extract data part (excluding the index in the first row)
    data = df.iloc[1:, :].values

    # List to store results
    result = []

    # Iterate over all cells
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            # Skip cells where row number equals column number (diagonal values)
            if i == j:
                continue
            value = data[i, j]
            Gi, Gj = i+1, j+1
            result.append(("G"+str(Gi), "G"+str(Gj), value))

    # Sort by regulatory value in descending order
    result_sorted = sorted(result, key=lambda x: x[2], reverse=True)

    # Convert to DataFrame
    output_df = pd.DataFrame(result_sorted, columns=['Row', 'Column', 'Value'])

    # Save to CSV file
    output_df.to_csv('AUROC_AUPR/test_size100_{}.csv'.format(num_table), header=False, index=False)

    print(f"\nSorting completed for table {num_table}, Found {len(result_sorted)} regulatory values.")
    print(f"Top 3 maximum values:")
    for i in range(3):
        print(f"  Rank {i+1}: {result_sorted[i][2]} (Position: Row {result_sorted[i][0]}, Column {result_sorted[i][1]})")
