from AUROC_AUPR_dream4 import *
import pandas as pd

def main():
    auroc = []
    aupr = []
    for num_table in range(1, 6):
        # File paths
        gold_file = "AUROC_AUPR/gold_size100_{}.csv".format(num_table)
        test_file = "AUROC_AUPR/test_size100_{}.csv".format(num_table)
        
        print("\n\nReading gold file {}...".format(num_table))
        gold_edges, num_row = read_gold_edges(gold_file)
        print(f"Read {num_row} true edges from gold file")
        
        print("\nReading test file {}...".format(num_table))
        predictions = read_predictions(test_file)
        print(f"Read {len(predictions)} predicted edges from test file")
        
        print("\nCalculating evaluation metrics...")
        auroc_current, aupr_current, precision, recall, fpr, tpr, y_true, y_score = calculate_metrics(gold_edges, predictions)
        
        print(f"\n========== Results ==========")
        print(f"AUROC_{num_table}: {auroc_current:.6f}")
        print(f"AUPR_{num_table}: {aupr_current:.6f}")
        auroc.append(auroc_current)
        aupr.append(aupr_current)
    
        # Display some statistical information
        print(f"\n========== Statistics ==========")
        print(f"Total edges considered: {len(y_true)}")
        print(f"True positives: {np.sum(y_true)}")
        print(f"True negatives: {len(y_true) - np.sum(y_true)}")
        print(f"Prediction score range: [{np.min(y_score):.6f}, {np.max(y_score):.6f}]")
        print(f"Mean prediction score: {np.mean(y_score):.6f}")
    
        # Display some prediction examples
        print(f"\n========== Prediction Examples ==========")
        print("Top 5 predicted edges (sorted by score descending):")
        sorted_predictions = sorted(predictions.items(), key=lambda x: x[1], reverse=True)
        for i, ((src, dst), score) in enumerate(sorted_predictions[:5]):
            is_correct = (src, dst) in gold_edges
            status = "✓" if is_correct else "✗"
            print(f"  {status} {src}->{dst}: {score:.6f} {'(correct)' if is_correct else '(incorrect)'}")
    
        # Display prediction score distribution for positives and negatives
        print(f"\nMean prediction score for positives: {np.mean(y_score[y_true == 1]):.6f}")
        print(f"Mean prediction score for negatives: {np.mean(y_score[y_true == 0]):.6f}")
        
        print(f"auroc_{num_table} value: {auroc_current}")
        print(f"aupr_{num_table} value: {aupr_current}")
    print(f"auroc values: {auroc}")
    print(f"aupr values: {aupr}")

    with open("AUROC_AUPR/AUROC_AUPR.txt", 'w', encoding='utf-8') as result_file:
        result_file.write(f"auroc values: {auroc}\n")  # Write auroc values
        result_file.write(f"aupr values: {aupr}")  # Write aupr values

    return auroc, aupr

if __name__ == "__main__":
    auroc, aupr = main()
    