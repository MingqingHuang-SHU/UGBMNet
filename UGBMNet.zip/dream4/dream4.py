from UGBMNet_dream4 import *
import pandas as pd

alpha = [0.450, 0.455, 0.470, 0.425, 0.465]
k = [3, 2, 2, 2, 3]

for i in range(1, 6):
    # Read data
    file_tm = "data/timeseries_data/insilico_size100_{}_timeseries.csv".format(i)
    tm = pd.read_csv(file_tm).to_numpy()
    file_ko = "data/knockout_data/insilico_size100_{}_knockout.csv".format(i)
    ko = pd.read_csv(file_ko).to_numpy()

    # Compute weights of gene regulatory network
    mgr = main(tm, 10, k[i-1], alpha[i-1], 5000, ko)

    # Export result
    df = pd.DataFrame(mgr)
    df.to_csv("results/dream4_d{}.csv".format(i), index=False)
