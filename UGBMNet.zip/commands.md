We conducted the experiments on Ubuntu-22.04 with Python-3.10 and Miniconda3. 
To run the code, please execute the following commands.

(1) Environment configuration:
	unzip UGBMNet.zip
	cd UGBMNet
	conda create --name ugbmnet python=3.10 -y
	conda activate ugbmnet
	pip install optuna pandas numpy scikit-learn matplotlib
	bash compile.sh

(2) Handling the DREAM4 dataset:
	cd dream4
	python3 dream4.py
	python3 value_sort.py
	python3 AUROC_AUPR.py

(3) Handling the E.coli dataset:
	cd ../Ecoli
	python3 Ecoli.py
	python3 value_sort.py
	python3 AUROC_AUPR.py
